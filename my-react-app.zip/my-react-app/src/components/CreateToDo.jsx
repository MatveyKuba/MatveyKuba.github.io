import { useState } from "react"
import '../App.css'

function CreateToDo({setTodos}){

    const [description, setDescription] = useState('');

    function addTask(description){
		setTodos(prev =>[ {
			id: new Date(),
			description,
			isCompleted: false,
		}, ...prev,
	])
		setDescription('')
	}
    return(
        <div>
            <input type="text" className="addTask" placeholder="Add Task"
            onChange={e => setDescription(e.target.value)} 
            value={description} 
            onKeyPress={(e) => e.key === 'Enter' && addTask(description)}/>
        </div>
    )
}
export default CreateToDo