import { useState } from "react"
import ToDoItem from "./ToDoItem"
import CreateToDo from "./CreateToDo"

const data = [
{
	id: 434234,
	description: 'Make a book',
	isCompleted: false,
},
{
	id: 43423121,
	description: 'Read a book',
	isCompleted: false,
},
{
	id: 431114234,
	description: 'Throw a book',
	isCompleted: false,
},

]


function MainToDo() {

	const [todos, setTodos] = useState(data)
	
	function handlerAdd(id){
		const copyTodos = [...todos];
		const current = copyTodos.find(elem => elem.id === id)
		current.isCompleted = !current.isCompleted;
		setTodos(copyTodos)

	}
	
	
	function handlerDelete(id){
	
		setTodos([...todos].filter(elem => elem.id !== id))

	}



	return(
		<div>
		<div>
			{todos.map(todo => <ToDoItem  todo={todo} key={todo.id} handlerAdd={handlerAdd} handlerDelete={handlerDelete} />)}
		</div>
		<CreateToDo setTodos={setTodos}/>
		</div>
	)
}

export default MainToDo